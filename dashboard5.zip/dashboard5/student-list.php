<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                <div class="searchbutton">
                        <label for="">Search</label>
                        <input type="search" name="search" value="" placeholder="Search">
                    </div><br><br>
                    <?php
                       try{
                            include_once('message.php');
                            $pass = $_SESSION['password'];
                            if($pass == true){

                            }else{
                                header('location:index.php');
                            }
                    
                        $studentQuery = "SELECT * FROM student";
                        $stdata = $conn->query($studentQuery);
                    ?>
                    <button><a href="student-form.php">Add New Data</a></button><br>
                        <?php include_once('message.php');?>
                        <br><h2>Student Data</h2><br>
                        <div class="figure">
                            <table border>
                                <tr>
                                    <th>Id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Gender</th>
                                    <th>Subject</th>
                                    <th>Password</th>
                                    <th>Address</th>
                                    <th>Pincode</th>
                                    <th>Date</th>
                                    <th colspan="2">Action</th>
                                </tr>
                                    <?php
                                        if($stdata->num_rows){
                                            $i=1;
                                            while($data = $stdata->fetch_assoc()){
                                    ?>
                                                <tr>
                                                    <td><?=$i++?></td>
                                                    <td><?=$data['firstname']?></td>
                                                    <td><?=$data['lastname']?></td>
                                                    <td><?=$data['email']?></td>
                                                    <td><?=$data['gender']?></td>
                                                    <td><?=$data['subject']?></td>
                                                    <td><?=$data['password']?></td>
                                                    <td><?=$data['address']?></td>
                                                    <td><?=$data['pincode']?></td>
                                                    <td><?=$data['created_at']?></td>
                                                    <td><button id="edit"><a href="student-edit.php?id=<?=$data['id']?>">Edit</a></button></td>
                                                    <td><button id="delete"><a href="student-delete.php?id=<?=$data['id']?>">Delete</a></button></td>
                                                </tr>
                                <?php
                                            }
                                        }
                                    }catch(Exception $e){
                                        echo $e->getMessage();
                                    }
                                ?>
                            </table>
                        </div>
                </div>
            </section>
        </div>
    </div>
</body>
</html>