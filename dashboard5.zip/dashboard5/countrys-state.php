<?php
    include_once('config.php');
   try{
        $countryId = $_REQUEST['country_id'];
        $states = "SELECT * FROM `states` WHERE country_id=$countryId";
        $statesData = $conn->query($states);
 ?>
     <option value="">-- Selecte State --</option>
          <?php
               while($state = $statesData->fetch_assoc()){
          ?>      
                    <option value="<?=$state['id']?>"><?=$state['name']?></option>  
          <?php
               }
          ?>
<?php
     
   }catch(Exception $e){
        echo $e->getMessage();
   }



?>

