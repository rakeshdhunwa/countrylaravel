<?php
    include_once('config.php');
    $email = $_POST['email'];
    $password = $_POST['password'];
    $query = "SELECT * FROM user WHERE email='$email' AND password='$password'";
    $datas = $conn->query($query);

 try{
        if($datas->num_rows){
            $emailpass = $datas->fetch_assoc();
            if($emailpass){
                $_SESSION['email'] = "Welcome "."$email";
                $_SESSION['password'] = "$password";
                header('location:dashboard.php');                                       
            }else{  
                header('location:index.php');
                $_SESSION['notmatch'] = "please enter confirm password and email";
            }
        }else{
            header('location:index.php');
            $_SESSION['notmatch'] = "please enter confirm password and email";
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }

?>