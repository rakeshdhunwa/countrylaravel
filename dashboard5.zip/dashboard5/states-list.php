<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                        include_once('message.php');
                        $pass = $_SESSION['password'];
                        if($pass == true){

                        }else{
                            header('location:index.php');
                        }
                    ?>
                    <?php
                        try{
                            $conQuery = "SELECT st.*,ct.name as country_name FROM `states` as st, countries_table as ct where ct.id=st.country_id";
                            $states = $conn->query($conQuery);
                    ?>
                        <button><a href="states-form.php">Add New Data</a></button><br><br>
                        <?php include_once('message.php');?><br>
                        <h2>States Data</h2><br>
                    <table border>
                        <tr>
                            <th>Id</th>
                            <th>Country Name</th>
                            <th>State Name</th>
                            <th>Status</th>
                            <th>Create Date</th>
                            <th colspan="2">Action</th>
                        </tr> 
                        <?php
                            if($states->num_rows){
                                $i=1;
                                while($state = $states->fetch_assoc()){
                        ?>  
                                    <tr>
                                        <td><?=$i++?></td>
                                        <td><?=$state['country_name']?></td>
                                        <td><?=$state['name']?></td>
                                        <td><?=($state['status']==1)?'Enabile':'Disable'?></td>
                                        <td><?=$state['created_at']?></td>
                                        <td><button id='edit'><a href="states-edit.php?id=<?=$state['id']?>">Edit</a></button></td>
                                        <td><button id='delete'><a href="states-delete.php?id=<?=$state['id']?>">Delete</a></button></td>
                                    </tr>    
                    <?php
                                }
                            }
                    ?>
                    </table>
                    <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                    ?>                
                </div>
            </section>
        </div>
    </div>
</body>
</html>