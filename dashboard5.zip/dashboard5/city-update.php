<?php
    include_once('config.php');
    $cityData = $_REQUEST;
    $id = $cityData['id'];
    $country_id = $cityData['country_id'];
    $state_id = $cityData['state_id'];
    $name = $cityData['name'];
    $status = $cityData['status'];

        try{
                $cityupdate = "UPDATE city SET country_id='$country_id',state_id='$state_id',name='$name',status='$status'WHERE id=$id";
                $conn->query($cityupdate);
                header('location:city-list.php');
                $_SESSION['countryedit'] = "Data Edit Successfully";
           

            if($_REQUEST['submit']){
                header('location:city-list.php');
            }elseif($_REQUEST['save_edit']){
                header("location:city-edit.php?id=$id");
            }else{
                header("location:city-form.php");
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
?>