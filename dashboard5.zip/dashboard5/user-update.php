<?php
    include_once('config.php');
    $userdata = $_REQUEST;
    $id = $userdata['id'];
    $name = $userdata['name'];
    $email = $userdata['email'];
    $password = $userdata['password'];

    include_once('message.php');
        $pass = $_SESSION['password'];
        if($pass == true){
        }else{
            header('location:index.php');
        }
    try{      
        $pass = "SELECT * FROM `user` WHERE email='$email' AND id!=$id";
        $emailpass = $conn->query($pass);

        if($emailpass->num_rows > 0){
            header('location:user-edit.php?id='.$id);
        }else{
            if($_SERVER['REQUEST_METHOD']=='POST'){             
                $userupQuery = "UPDATE user SET name='$name',email='$email',password='$password' WHERE id=$id";
                $conn->query($userupQuery);
                header('location:user-list.php');
            }else{
                header('location:user-list.php');
            }
        }       
    }catch(Exception $e){
        echo $e->getMessage();
    }
 
?>