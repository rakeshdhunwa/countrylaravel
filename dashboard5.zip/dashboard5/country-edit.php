<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                       try{
                        $id = $_REQUEST['id'];
                        $couneditQuery = " SELECT * FROM countries_table WHERE id=$id";
                        $countrydatas = $conn->query($couneditQuery);
                        $coundata = $countrydatas->fetch_assoc();

                        $statesQuery = "SELECT * FROM `states` WHERE country_id=$id";
                        $statesData = $conn->query($statesQuery);
                    ?>
                    <div class="form">
                        <h2>Country Data</h2>
                        <form action="country-update.php" method="post" style="background: transparent;">
                        <input type="hidden" value="<?=$coundata['id']?>" name="id">
                            <div class="figure">
                                <table border class="ctable">
                                    <tr> 
                                        <td>
                                            <label for="">Name</label>
                                        </td>
                                        <td>
                                            <input type="text" value="<?=$coundata['name']?>" name="name" required placeholder="Name">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label for="">Status</label></td>
                                        <td>
                                            <select name="status" id="status">
                                                <option value="1">Enable</option>
                                                <option value="2">Disable</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <tr>
                                            <td colspan="2">
                                            <button id="add" type="button">Add New State</button>
                                            <hr style="margin-top:10px;">
                                               
                                                    <table class="ctable" id="table2">
                                                    <tr>
                                                            <th>State Name</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    <?php 
                                                while($_stdata = $statesData->fetch_assoc()){
                                                    
                                                    ?>
                                                        
                                                    
                                                        <tr class="border">
                                                            <input type="hidden" value="<?=$_stdata['id']?>" name="state_id[]">

                                                            <td><input type="text" placeholder="Name" name="state_name[]" value="<?=$_stdata['name']?>"></td>
                                                            <td><select name="state_status[]" id="status" value="<?=$_stdata['status']?>" >
                                                                <option value="1">Enable</option>
                                                                <option value="2">Disable</option>
                                                                </select>
                                                            </td>
                                                            <td><button id="Remove" type="button">Remove</button></td>
                                                        </tr>
                                                    
                                                <?php
                                                }
                                                ?>
                                                </table>
                                            </td>
                                        </tr>
                                        <td>
                                            <input type="submit" name="submit" value="Save">
                                            <input type="submit" name="save_edit" value="Save & Edit">
                                            <input type="submit" name="save_new" value="Save & New">
                                        </td>
                                    </tr>
                                </table>
                            </div>    
                        </form>
                    </div>
                    <?php
                       }catch(Exception $e){
                        echo $e->getMessage();
                       }
                    ?>
                </div>
            </section>
        </div>
    </div>

<script>
   $(document).ready(function(){
        var varebl ='<tr><td><input type="text" name="state_name[]" value=""required  placeholder="Name"/></td><td><select name="state_status[]" id="status"><option value="1">Enable</option><option value="2">Disable</option></select> </td><td><button id="Remove">Remove</button></td></tr>';
        $('#add').click(function(){
            $('#table2').append(varebl);
        });

        $('table').on('click','#Remove',function(){
            $(this).closest('tr').remove();
        });
   });
</script>
</body>
</html>