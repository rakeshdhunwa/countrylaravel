<?php
    include_once('config.php');
    $id = $_REQUEST['id'];
    try{
        if($id){
            $countrydelete = "DELETE FROM city WHERE id=$id";
            $conn->query($countrydelete);
            header('location:city-list.php');
            $_SESSION['success'] = "Data Delete Successfully";
        }else{
            $_SESSION['error'] = "Error"; 
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }

?>