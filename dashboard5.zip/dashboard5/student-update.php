<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<?php
    include_once('config.php');
    
       $stdata = $_REQUEST;
       $id = $stdata ['id'];
       $firstname = $stdata ['fname'];
       $lastname = $stdata ['lname'];
       $email = $stdata ['email'];
       $gender = $stdata ['gender'];
       $password = $stdata ['password'];
       $address = $stdata ['address'];
       $pincode = $stdata ['pincode'];
       
        try{
            if($_SERVER['REQUEST_METHOD']=='POST'){
            $stupdate = "UPDATE student SET firstname='$firstname',lastname='$lastname',email='$email',gender='$gender',password='$password',address='$address',pincode='$pincode' WHERE id=$id";
            $conn->query($stupdate);
            header('location:student-list.php');
            }else{
                header('location:student-list.php');   
            }
        } catch(Exception $e){
            echo $e->getMessage();
        }
    
     

?>