<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <div class="searchbutton">
                        <label for="">Search</label>
                        <input type="search" name="search" value="" placeholder="Search">
                    </div>
                    <div class="form">
                        <h2>City Form</h2>
                        <form action="city-create.php" method="post">
                                    <label for="">Country Name</label><br>
                                    <select name="country_id" id="country">
                                        <option value="">-- Selecte Country --</option>
                                        <?php
                                            $conQuery = "SELECT * FROM countries_table";
                                            $contries = $conn->query($conQuery);
                                            while($country = $contries->fetch_assoc()){
                                        ?>    
                                                <option value="<?=$country['id']?>"><td><?=$country['name']?></td></option>  
                                        <?php
                                            }
                                        ?>
                                    </select><br><br>
                                    
                                    <label for="">State Name</label><br>
                                    <select name="state_id" id="state">
                                        <option value="" selected>-- Selecte State --</option>
                                    </select><br><br>

                                    <label for="">City Name</label><br>
                                    <input type="text" value="" name="name" required placeholder="name"><br>

                                    <label for="">Status</label><br>
                                    <select name="status" id="status">
                                        <option value="1">Enable</option>
                                        <option value="2">Disable</option>
                                    </select> <br><br>
                                    <input type="submit" name="submit" value="Save"><br>
                                    <input type="submit" name="save_new" value="Save & New"><br>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script>
        $(document).ready(function(){
            $("#country").change(function(){

                var countryId = $(this).val();

                $.ajax({
                    url: 'get-states.php',
                    method: 'POST',
                    data: {'cunt_id': countryId},
                    success: function(res){
                        //alert(res);
                        $("#state").html(res);
                    }

                });

            });

        });
    </script>
</body>
</html>