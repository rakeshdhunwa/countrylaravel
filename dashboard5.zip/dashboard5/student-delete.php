<?php
    include_once('config.php');

    $id = $_REQUEST['id'];
   try{
        if($id){
            $stDelete = "DELETE FROM student WHERE id=$id";
            $conn->query($stDelete);
            $_SESSION['success'] = "Data Delete successfully";
            header('location:student-list.php'); 
            }else{
                $_SESSION['error'] = "Error";
            }
   }catch(Exception $e){
    echo $e->getMessage();
   }

?>