<?php
    include_once('config.php');
    $data = $_REQUEST;
    
    $country_id = $data['country_id'];
    $name = $data['name'];
    $status = $data['status'];

     $city_name = $data['city_name'];
     $city_status = $data['city_status'];
     
    
    
    try{
      
            $insstates = "INSERT INTO `states`(`country_id`,`name`,`status`)VALUES($country_id,'$name','$status')";
            $instst = $conn->query($insstates);
            $status_id = $conn->insert_id;

            foreach($city_name as $key => $city){
                $statusct = $city_status[$key];
                
                $instcity = "INSERT INTO `city` (`country_id`,`state_id`,`name`,`status`)VALUES($country_id,'$status_id','$city','$statusct')";
                $conn->query($instcity);
            }
       
        if($_REQUEST['submit']){
            header('location:states-list.php');
        }else{
            header('location:states-form.php');
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }
?>