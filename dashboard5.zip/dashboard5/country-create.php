<?php
    include_once('config.php');

    $data = $_REQUEST;
    $name = $data['name'];
    $status = $data['status'];

    $states = $data['state_name'];
    $state_status = $data['state_status'];
    
    try{
        
            $insCountry = "INSERT into countries_table(name, status) VALUES('$name', $status)";
            $insetCount = $conn->query($insCountry);
            $countryId = $conn->insert_id;

            foreach($states as $key => $_state) {
                $status = $state_status[$key];
                $name = $_state;

                $insState = "INSERT INTO states(country_id, name, status) VALUES($countryId, '$name', $status)";
                $conn->query($insState);
            }
            $_SESSION['success'] = "Record Created Successfully....";
            header("location: country-list.php");
      
            if($_REQUEST['submit']){
                header("location: country-list.php");
            }elseif($_REQUEST['save_new']){
                 header("location: country-form.php");
            }
    }catch(Exception $e){
        echo $e->getMessage();
    }


?>