
<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php

                        try{
                            $id = $_REQUEST['id']??0;
                            $cityQuery = " SELECT * FROM city WHERE id=$id";
                            $citydatas = $conn->query($cityQuery);
                            $citydata = $citydatas->fetch_assoc();
                    ?>
                            <div class="form">
                                <h2>City Data</h2>
                                <form action="city-update.php" method="post">
                                    <input type="hidden" value="<?=$citydata['id']?>" name="id">
                                    <label for="">Country name</label><br>
                                    
                                    <select name="country_id" id="country">
                                        <option value="">-- Selecte Country --</option>
                                        <?php
                                            $conQuery = "SELECT * FROM countries_table";
                                            $contries = $conn->query($conQuery);
                                            while($country = $contries->fetch_assoc()){
                                        ?>    
                                                <option value="<?=$country['id']?>" <?= ($citydata['country_id']==$country['id'])?'selected':''?> ><?=$country['name']?></option>  
                                        <?php
                                            }
                                        ?>
                                    </select>
                                    <br>

                                    <label for="">State Name</label><br>
                                    <select name="state_id" id="state">
                                        <option value="">-- Selecte State --</option>
                                        <?php
                                            $selState = "SELECT * FROM states WHERE country_id=".$citydata['country_id'];
                                            $states = $conn->query($selState);
                                            while($state = $states->fetch_assoc()){
                                        ?>    
                                                <option value="<?=$state['id']?>" <?= ($citydata['state_id']==$state['id'])?'selected':''?> ><?=$state['name']?></option>  
                                        <?php
                                            }
                                        ?>
                                    </select>

                                    <label for="">Name</label><br>
                                    <input type="text" value="<?=$citydata['name']?>" name="name" required placeholder="name"><br>

                                    <label for="">Status</label><br><br>
                                    <select name="status" id="status">
                                        <option value="1" <?=($citydata['status']=='1')?'selected':''?>>Enable</option>
                                        <option value="2" <?=($citydata['status']=='2')?'selected':''?>>Disable</option>
                                    </select><br><br>
                                    
                                    <input type="submit" name="submit" value="Save"><br>
                                    <input type="submit" name="save_edit" value="Save & Edit"><br>
                                    <input type="submit" name="save_new" value="Save & New"><br>

                                </form>
                            </div>
                            <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                            }
                            ?>
        
                </div>
            </section>
        </div>
    </div>
</body>
</html>