<?php
    include_once('config.php');
    $countryData = $_REQUEST;
    $id = $countryData['id'];
    $name = $countryData['name'];
    $status = $countryData['status'];

  $states = $countryData['state_name'];
  $state_status = $countryData['state_status'];
  $state_id = $countryData['state_id'];

  $stid = implode(",",$countryData['state_id']);

    try{
        
            $counupdate = "UPDATE countries_table SET name='$name',status='$status' WHERE id=$id";
            $conn->query($counupdate);

            $stDelete = "DELETE FROM `states` WHERE id NOT IN($stid) AND country_id=$id";
            $conn->query($stDelete);
            foreach($states as $key => $_state) {
                $statues = $state_status[$key];
                 $_id = $state_id[$key];
                $name = $_state;
                if($_id){
                    $updateState = "UPDATE `states` SET country_id='$id',name='$name',status='$statues' WHERE id=$_id";
                     $conn->query($updateState);
                    header('location:country-list.php');
                }else{
                    $insState = "INSERT INTO `states`(`country_id`,`name`,`status`)VALUES('$id','$name','$statues')";
                    $conn->query($insState);
                    header('location:country-list.php');
                }
            }
            header('location:country-list.php');
            $_SESSION['countryedit'] = "Data Edit Successfully";
       
                if($_REQUEST['submit']){
                    header('location:country-list.php');
                }elseif($_REQUEST['save_edit']){
                    header("location:country-edit.php?id=$id");
                }else{
                    header('location:country-form.php');
                }
                       
    }catch(Exception $e){
        echo $e->getMessage();
    }
?>