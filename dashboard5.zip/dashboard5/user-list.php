<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                        try{
                        include_once('config.php');
                        $userQuery = "SELECT * FROM user";
                        $userdata = $conn->query($userQuery);
                    ?>
                    <?php 
                        include_once('message.php');
                        $pass = $_SESSION['password'];
                        if($pass == true){
                        }else{
                            header('location:index.php');
                        }
                    ?>
                        <button><a href="user-form.php">Add New Data</a></button><br><br>
                        <h2>User Data</h2><br>
                        <table border>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Date</th>
                                <th colspan="2">Action</th>
                            </tr>
                            <?php
                                if($userdata->num_rows){
                                    $i=1;
                                while($usdata = $userdata->fetch_assoc()){
                            ?>      
                                    <tr>
                                        <td><?=$i++?></td>
                                        <td><?=$usdata['name']?></td>
                                        <td><?=$usdata['email']?></td>
                                        <td><?=$usdata['password']?></td>
                                        <td><?=$usdata['created_at']?></td>
                                        <td><button id="edit"><a href="user-edit.php?id=<?=$usdata['id']?>">Edit</a></button></td>
                                        <td><button id="delete"><a href="user-delete.php?id=<?=$usdata['id']?>">Delete</a></button></td>
                                    </tr>
                            <?php
                                    }
                                }
                            ?>
                        </table>
                    <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                    ?>
                </div>
            </section>
        </div>
    </div>
</body>
</html>