<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body> 
    <?php
        $pass = $_SESSION['password'];
        if($pass == true){

        }else{
            header('location:index.php');
        }
    ?>            
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                <div class="form">
        <form action="user-create.php" method="post">
            <label for="">Name</label><br>
            <input type="text" name="name" value="" required placeholder="First Name"><br>

            <label for="">Email</label><br>
            <input type="email" name="email" value="" required placeholder="Email"><br>

            <label for="">Password</label><br>
            <input type="tel" name="password" value="" required placeholder="Password">
               <br>&nbsp <?php include_once('message.php');?>
            <input type="submit" name="submit" value="submit"><br>
        </form>
    </div>
        
                </div>
            </section>
        </div>
    </div>
</body>
</html>