<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br><br>
                <div id="data"></div><br><br>
                <h2 style="font-size:40px;">Welcome Dashboard</h2>
                    <?php
                    include_once('message.php');
                    $pass = $_SESSION['password'];
                    if($pass == true){

                    }else{
                        header('location:index.php');
                    }
                    ?>
                </div>
            </section>
        </div>
    </div>

    <script>
    setInterval(function(){
        var dt = new Date();
        var time = dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
        $("#data").html(time);
    }, 1000);
</script>
</body>
</html>