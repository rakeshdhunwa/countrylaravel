
<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                        include_once('message.php');
                        $pass = $_SESSION['password'];
                        if($pass == true){

                        }else{
                            header('location:index.php');
                        }
                    ?>
                    <?php
                        try{
                            $conQuery = "SELECT * FROM countries_table";
                            $contries = $conn->query($conQuery);
                    ?>
                            <button><a href="country-form.php">Add New Data</a></button><br><br>
                            <?php include_once('message.php');?><br>
                            <h2>Countries Data</h2><br>
                            <div class="figure">
                                <table border>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Create Date</th>
                                        <th colspan="2">Action</th>
                                    </tr>  
                                    <?php
                                        if($contries->num_rows){
                                            $i=1;
                                            while($countery = $contries->fetch_assoc()){
                                    ?>  
                                                <tr>
                                                    <td><?=$i++?></td>
                                                    <td><?=$countery['name']?></td>
                                                    <td><?=($countery['status']=='1')?'Enable':'Disable'?></td>
                                                    <td><?=$countery['created_at']?></td>
                                                    <td><button id='edit'><a href="country-edit.php?id=<?=$countery['id']?>">Edit</a></button></td>
                                                    <td><button id='delete'><a href="country-delete.php?id=<?=$countery['id']?>">Delete</a></button></td>
                                                </tr>    
                                    <?php
                                            }
                                        }
                                    ?>
                                </table>
                            </div>
                        <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                        ?>                
                </div>
            </section>
        </div>
    </div>
</body>
</html>