$(document).ready(function() {
    $(".mobilemenu").click(function(){
        $(".navbar").toggleClass("active");
    });
});