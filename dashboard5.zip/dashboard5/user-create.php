<?php
    include_once('config.php');

    try{
        $usdata = $_REQUEST;
        $name = $usdata['name'];
        $email = $usdata['email'];
        $password = $usdata['password'];
    
        $emailpass = "SELECT * FROM user WHERE email='$email'";
        $pass = $conn->query($emailpass);
        if($pass->num_rows){
            $_SESSION['oneemail'] = "This ID is already received";
            header('location:user-form.php');
        }else{
            if($_SERVER['REQUEST_METHOD']=='POST' && isset($usdata['submit'])){
                $inQuery = "INSERT INTO user(`name`,`email`,`password`)VALUES('$name','$email','$password')";
                $conn->query($inQuery);
                header('location:user-list.php');
            }
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }
?>