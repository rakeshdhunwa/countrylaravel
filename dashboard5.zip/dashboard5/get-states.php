<?php
include_once('config.php');
$countId = $_POST['cunt_id'];

$selState = "SELECT * FROM states WHERE country_id=$countId";
$stateData = $conn->query($selState);

?>
<option value="">-- Selecte State --</option>
<?php
while($state = $stateData->fetch_assoc()) {
    ?>
    <option value="<?= $state['id']?>"><?= $state['name']?></option>
    <?php
}

?>