<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                            include_once('message.php');
                            $pass = $_SESSION['password'];
                            if($pass == true){

                            }else{
                                header('location:index.php');
                            }
                        ?>
                    <div class="form">
                        <?php include_once('message.php');?>
                        <form action="student-create.php" method="post">
                            <label for="">First Name</label><br>
                            <input type="text" name="fname" value="" required placeholder="First Name"><br>

                            <label for="">Last Name</label><br>
                            <input type="text" name="lname" value="" required placeholder="Last Name"><br>

                            <label for="">Email</label><br>
                            <input type="email" name="email" value="" required placeholder="Email"><br>

                            
                            <input type="radio" name="gender" value="male" required id="Male" class="same">
                            <label for="Male">Male</label><br>

                            <input type="radio" name="gender" value="female" required id="Female" class="same">
                            <label for="Female">Female</label><br><br>

                            <input type="checkbox" name="subject[]" value="hindi" class="same" id="h">
                            <label for="h">Hindi</label><br>
                            <input type="checkbox" name="subject[]" value="english" class="same" id="e">
                            <label for="e">English</label><br>
                            <input type="checkbox" name="subject[]" value="chemistry" class="same" id="c">
                            <label for="c">Chemistry</label><br>

                           <br> <label for="">Password</label><br>
                            <input type="tel" name="password" value="" required placeholder="Password"><br><br>

                            <label for="">Address</label><br>
                            <textarea name="address"></textarea><br><br>

                            <label for="">Pincode</label><br>
                            <input type="tel" name="pincode" value="" required placeholder="Pincode"><br>

                            
                            <input type="submit" name="submit" value="submit"><br>
                        </form>
                    </div>  
                </div>
            </section>
        </div>
    </div>
</body>
</html>