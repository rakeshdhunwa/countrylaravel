<?php
    include_once('config.php');

    $id = $_REQUEST['id'];

  try{
    if($id){

        $cityDelete = "DELETE FROM `city` WHERE state_id=$id";
        $conn->query($cityDelete);
        
        $deleteQuery = "DELETE FROM `states` WHERE id=$id";
        $conn->query($deleteQuery);

        header('location:states-list.php');
        $_SESSION['statesdelete'] = "Data Delete Sucessfully";
    }else{
        $_SESSION['error'] = "Error";
    }
  }catch(Exception $e){
    echo $e->getMessage();
  }


?>