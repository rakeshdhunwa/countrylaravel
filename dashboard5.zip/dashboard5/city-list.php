<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                        include_once('message.php');
                        $pass = $_SESSION['password'];
                        if($pass == true){
                        }else{
                            header('location:index.php');
                        }
                    ?>
                    <?php
                        include_once('config.php');
                        $cityQuery = "SELECT ct.*, cnt.name as country_name, st.name as state_name FROM `city` as ct, countries_table as cnt, states as st WHERE cnt.id=ct.country_id and st.id=ct.state_id";
                        $citydatas = $conn->query($cityQuery);
                        //print_r($citydatas);
                        try{
                    ?>
                            <h2>City Data</h2><br>
                            <button><a href="city-form.php">Add New Data</a></button>
                            <table border>
                                    <tr>
                                        <th>Id</th>
                                        <th>Country Name</th>
                                        <th>State Name</th>
                                        <th>City Name</th>
                                        <th>Status</th>
                                        <th>Created_Date</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                <?php 
                                    if($citydatas->num_rows){
                                        $i=1;
                                        while($data = $citydatas->fetch_assoc()){
                                ?>          <tr>    
                                                <td><?=$i++?></td>
                                                <td><?=$data['country_name']?></td>
                                                <td><?=$data['state_name']?></td>
                                                <td><?=$data['name']?></td>
                                                <td><?=($data['status']=='1')?'Enable':'Disable';?></td>
                                                <td><?=$data['created_at']?></td>
                                                <td><button id="edit"><a href="city-edit.php?id=<?=$data['id']?>">Edit</a></button></td>
                                                <td><button id="delete"><a href="city-delete.php?id=<?=$data['id']?>">Delete</a></button></td>
                                            </tr>
                    <?php
                                    }
                                }
                        }catch(Exception $e){
                            echo $e->getMessage();
                        } 
                    ?>
                            </table>    
                </div>
            </section>
        </div>
    </div>
</body>
</html>