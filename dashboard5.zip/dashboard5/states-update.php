<?php
    include_once('config.php');

    $updata = $_REQUEST;
     $id = $updata['id'];
     $country_id = $updata['country_id'];
     $name = $updata['name'];
     $status = $updata['status'];
    
   try{
       
            $updateQuery = "UPDATE states SET country_id='$country_id',name='$name',status='$status' WHERE id=$id";
            $conn->query($updateQuery);
                
                $city_id = $updata['city_id']??[0];
                $ct_id = implode(" , ", $city_id);
                $cityDelete = "DELETE FROM `city` WHERE id NOT IN ($ct_id) AND state_id=$id";
                $conn->query($cityDelete);
                if(isset($updata['city_name'])){
                    $city_name = $updata['city_name'];
                    $city_status = $updata['city_status'];

                    foreach($city_name as $key => $_city) {
                        $cityes = $city_status[$key];
                        $_id = $city_id[$key];
                    
                        if($_id){
                            $updateState = "UPDATE `city` SET country_id='$country_id',state_id='$id',name='$_city',status='$cityes' WHERE id=$_id";
                            $conn->query($updateState);
                            header('location:states-list.php');
                        }else{
                            $inscity = "INSERT INTO `city`(`country_id`,`state_id`,`name`,`status`)VALUES('$country_id','$id','$_city','$cityes')";
                            $conn->query($inscity);
                            header('location:states-list.php');
                        }
                    }
                    header('location:states-list.php');
                }else{
                    header('location:states-list.php');
            }
        

        if($_REQUEST['submit']){
            header('location:states-list.php');
        }elseif($_REQUEST['save_edit']){
            header("location:states-edit.php?id=$id");
        }else{
            header("location:states-form.php");
        }
   }catch(Exception $e){
    echo $e->getMessage();
   }

?>