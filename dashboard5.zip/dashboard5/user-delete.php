<?php
    include_once('config.php');

    $id = $_REQUEST['id'];
   try{
        if($id){
            $usdelQuery = "DELETE FROM user WHERE id=$id";
            $conn->query($usdelQuery);
            header('location:user-list.php');
            $_SESSION['success'] = "Data Delete Successfully";
        }else{
            $_SESSION['error'] = "Data Delete Successfully";
        }
   }catch(Exception $e){
    echo $e->getMessage();
}

?>