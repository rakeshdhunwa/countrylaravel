<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>               
                    <?php
                        try{
                            $id = $_REQUEST['id'];
                            if($_REQUEST['id']){
                                $editQuery = "SELECT * FROM states WHERE id=$id";
                                $datas = $conn->query($editQuery);
                                $stdata = $datas->fetch_assoc();
                            }else{
                                header('location:states-list.php');
                            }

                            $cty_Query = "SELECT * FROM `city` WHERE state_id=$id";
                            $ctyData = $conn->query($cty_Query);
                    ?>
                            <div class="form">
                                <h2>States Data</h2>
                                <form action="states-update.php" method="post" style="background-color:transparent;">
                                <input type="hidden" name="id" value="<?=$stdata['id']?>">
                                <table border id="stable" >
                                <tr>
                                    <td><label for="">Country Name</label></td>
                                    <td>
                                        <select name="country_id" id="country">
                                            <option value="">-- Selecte Country --</option>
                                            <?php
                                                $conQuery = "SELECT * FROM countries_table";
                                                $contries = $conn->query($conQuery);
                                                while($country = $contries->fetch_assoc()){
                                            ?>    
                                                <option value="<?=$country['id']?>" <?= ($stdata['country_id']==$country['id'])?'selected':''?> ><?=$country['name']?></option>  
                                            <?php
                                                }
                                            ?>
                                        </select><br><br>
                                    </td>
                                </tr>
                            
                                <tr>          
                                    <td>
                                        <label for="">Add New States Name</label>
                                    </td>
                                    <td>
                                        <input type="text" value="<?=$stdata['name']?>" name="name"  placeholder="Name">
                                    </td>
                                </tr> 
                                <tr>
                                    <td colspan="2">
                                        <select name="status" id="status" value="">
                                            <option value="1">Enable</option>
                                            <option value="2">Disable</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        
                                        <table id="table2">
                                            <tr<td><button id="add" type="button">Add New City</button></td></tr>
                                            <hr style="margin-top:10px;">
                                            <tr>
                                                <th>City Name</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                               <?php
                                                    while($ct_Data = $ctyData->fetch_assoc()){
                                               ?>

                                            <tr>
                                                <input type="hidden" name="city_id[]" value="<?=$ct_Data['id']?>">
                                                <td><input type="text" name="city_name[]" required placeholder="Name" value="<?=$ct_Data['name']?>"></td>
                                                <td>
                                                    <select name="city_status[]" id="status" value="<?=$ct_Data['status']?>">
                                                        <option value="1" <?=($ct_Data['status']==1)?'selected':''?>>Enable</option>
                                                        <option value="2" <?=($ct_Data['status']==2)?'selected':''?>>Disable</option>
                                                    </select>
                                                </td>
                                                <td><button id="Remove" type="button">Remove</button></td>
                                            </tr>
                                            <?php
                                                    }
                                            ?>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td><input type="submit" name="submit" value="Save"></td>
                                    <td><input type="submit" name="save_edit" value="Save $ Edit"></td>
                                    <td><input type="submit" name="save_new" value="Save & New"></td>

                                </tr>
                            </table>    
                                </form>
                            </div>
                            <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                            ?>
                </div>
            </section>
        </div>
    </div>


<script>
   $(document).ready(function(){
        var varebl ='<tr><th><input type="hidden" name="city_id[]"><input type="text" name="city_name[]" required  placeholder="Name"/></th><td><select name="city_status[]" id="status"><option value="1">Enable</option><option value="2">Disable</option></select> </td><td><button id="Remove">Remove</button></td></tr>';
        $('#add').click(function(){
            $('#table2').append(varebl);
        });

        $('table').on('click','#Remove',function(){
            $(this).closest('tr').remove();
        });
   });
</script>
</body>
</html>