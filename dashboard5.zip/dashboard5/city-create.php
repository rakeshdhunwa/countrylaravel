<?php
    include_once('config.php');
    $city = $_REQUEST;
    $country_id = $city['country_id'];
    $state_id = $city['state_id'];
    $name = $city['name'];
    $status = $city['status'];

   try{
   
            $cityQuery = "INSERT INTO `city`(`country_id`,`state_id`,`name`,`status`)VALUES('$country_id','$state_id','$name','$status')";
            $coudata = $conn->query($cityQuery);
            header('location:city-list.php');
            $_SESSION['adddata'] = "Data Add sucessfully";
    
        if($_REQUEST['submit']){
            header('location:city-list.php');
        }elseif($_REQUEST['save_new']){
            header('location:city-form.php'); 
        }
   }catch(Exception $e){
    echo $e->getMessage();
   }


?>