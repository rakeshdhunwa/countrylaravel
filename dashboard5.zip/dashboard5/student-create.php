<?php
    include_once('config.php');

    $stdata = $_REQUEST;
    $firstname = $stdata['fname'];
    $lastname  = $stdata['lname'];
    $email  = $stdata['email'];
    $gender  = $stdata['gender'];
    $subject  = implode(" | ", $stdata['subject']);
    $password  = $stdata['password'];
    $address  = $stdata['address'];
    $pincode  = $stdata['pincode'];
    
   try{

        $emailpass = "SELECT * FROM student WHERE email='$email'";
        $query = $conn->query($emailpass);
        if($query->num_rows){
            $_SESSION['oneemail'] = "This ID is already received";
            header('location:student-form.php');
        }else{
            if($_SERVER['REQUEST_METHOD']=='POST' && isset($stdata['submit'])){
                $stdataQuery = "INSERT INTO student(`firstname`,`lastname`,`email`,`gender`,`password`,`subject`,`address`,`pincode`)VALUES('$firstname','$lastname','$email','$gender','$password','$subject','$address','$pincode')";
                $conn->query($stdataQuery);
                header('location:student-list.php');
            }else{
                header('location:student-list.php');
            }
        }
   }catch(Exception $e){
    echo $e->getMessage();
   }
?>