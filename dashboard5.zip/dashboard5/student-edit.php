<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br> 
                    <?php
                    try{
                        $id = $_REQUEST['id'];
                        if($_REQUEST['id']){
                            $editQuery = "SELECT * FROM student WHERE id=$id";
                            $datas = $conn->query($editQuery);
                            $stdata = $datas->fetch_assoc();
                            $subjectdata = $stdata['subject'];
                            $subjectpass = explode(" | ", $subjectdata);
                            
                        }else{
                            header('location:student-list.php');
                        }
                    ?>
                    <div class="form">
                        <form action="student-update.php" method="post">
                            <label for="">First Name</label><br>
                            <input type="text" name="fname" value="<?=$stdata['firstname']?>" required placeholder="First Name"><br>
                            <input type="hidden" name="id" value="<?=$stdata['id']?>"><br>

                            <label for="">Last Name</label><br>
                            <input type="text" name="lname" value="<?=$stdata['lastname']?>" required placeholder="Last Name"><br>

                            <label for="">Email</label><br>
                            <input type="email" name="email" value="<?=$stdata['email']?>" required placeholder="Email"><br>

                            
                            <input type="radio" name="gender" value="male" required id="Male" class="same" <?=($stdata['gender']=='male')?'checked':''?>>
                            <label for="Male">Male</label><br>

                            <input type="radio" name="gender" value="female" required id="Female" class="same" <?=($stdata['gender']=='female')?'checked':''?>>
                            <label for="Female">Female</label><br><br>

                            <input type="checkbox" name="subject[]" value="hindi" class="same" id="h" <?= (in_array('hindi', $subjectpass))?'checked':''?>>
                            <label for="h">Hindi</label><br>
                            <input type="checkbox" name="subject[]" value="english" class="same" id="e" <?= (in_array('english', $subjectpass))?'checked':''?>>
                            <label for="e">English</label><br>
                            <input type="checkbox" name="subject[]" value="chemistry" class="same" id="c" <?= (in_array('chemistry', $subjectpass))?'checked':''?>>
                            <label for="c">Chemistry</label><br>

                            <br><label for="">Password</label><br>
                            <input type="tel" name="password" value="<?=$stdata['password']?>" required placeholder="Password"><br><br>

                            <label for="">Address</label><br>
                            <textarea name="address"><?=$stdata['address']?></textarea><br><br>

                            <label for="">Pincode</label><br>
                            <input type="tel" name="pincode" value="<?=$stdata['pincode']?>" required placeholder="Pincode"><br>

                            <input type="submit" name="submit" value="submit"><br>
                        </form>
                    </div>
                    <?php
                     }catch(Exception $e){
                        echo $e->getMessage();
                     }
                    ?>
                </div>
            </section>
        </div>
    </div>
</body>
</html>