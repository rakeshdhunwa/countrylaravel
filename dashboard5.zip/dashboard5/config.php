<?php

    session_start();
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dashboard5";
            
    try{
        $conn = mysqli_connect($host,$username,$password,$dbname);
    } catch(Exception $e){
        echo $e->getMessage();
    }
   





?>