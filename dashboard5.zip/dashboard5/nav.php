<nav>
            
    <div class="logo"><img src="logo-1.png" alt=""></div>
    <h3>Management</h3>
        <ul>
            <li id="first"><a href="dashboard.php"><ion-icon name="grid-outline"></ion-icon>Dashboard</a></li>
            <li><a href="student-list.php"><ion-icon name="document-outline"></ion-icon>Student</a></li>
            <li><a href="user-list.php"><ion-icon name="journal-outline"></ion-icon>User</a></li>
            <li><a href="country-list.php"><ion-icon name="cart"></ion-icon>Countries</a></li>
            <li><a href="states-list.php"><ion-icon name="sync"></ion-icon>States</a></li>
        </ul>
        <hr>
        <h3>Connection</h3>
        <ul>
            <li><a href="city-list.php"><ion-icon name="chatbubble-ellipses-outline"></ion-icon>City</a></li>
            <li><a href="#"><ion-icon name="server-outline"></ion-icon>Marketing Automation</a></li>
            <li><a href="#"><ion-icon name="mail-outline"></ion-icon>Email integration</a></li>
        </ul>
        <hr>
        <h3>Customer</h3>
        <ul>
            <li><a href="#"><ion-icon name="git-compare-outline"></ion-icon>Transaction</a></li>
            <li><a href="#"><ion-icon name="settings-outline"></ion-icon>Maintenance</a></li>
        </ul>


        
</nav>