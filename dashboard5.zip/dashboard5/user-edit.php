

<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <?php
                        include_once('message.php');
                        $pass = $_SESSION['password'];
                        if($pass == true){

                        }else{
                            header('location:index.php');
                        }
                    ?>
                    <?php
                        try{
                            $id = $_REQUEST['id'];
                            $edutuser = "SELECT * FROM user WHERE id=$id";
                            $userdata = $conn->query($edutuser);
                            $data = $userdata->fetch_assoc();
                    ?>
                            <div class="form">
                                <form action="user-update.php" method="post">
                                    <label for="">Name</label><br>
                                    <input type="text" name="name" value="<?=$data['name']?>" required placeholder="First Name"><br>
                                    <input type="hidden" name="id" value="<?=$data['id']?>">

                                    <label for="">Email</label><br>
                                    <input type="email" name="email" value="<?=$data['email']?>" required placeholder="Email"><br>

                                    <label for="">Password</label><br>
                                    <input type="tel" name="password" value="<?=$data['password']?>" required placeholder="Password"><br><br>

                                    <input type="submit" name="submit" value="submit"><br>
                                </form>
                            </div>
                    <?php
                        }catch(Exception $e){
                            echo $e->getMessage();
                        }
                    ?>
                </div>
            </section>
        </div>
    </div>
</body>
</html>