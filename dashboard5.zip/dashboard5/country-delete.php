<?php
    include_once('config.php');
    $id = $_REQUEST['id'];
    try{
        if($id){

            $cityDelete = "DELETE FROM  `city` WHERE country_id=$id";
            $conn->query($cityDelete);

            $stateDelete = "DELETE FROM `states` WHERE country_id=$id";
            $conn->query($stateDelete);

            $countrydelete = "DELETE FROM countries_table WHERE id=$id";
            $conn->query($countrydelete);
            header('location:country-list.php');
            $_SESSION['success'] = "Data Delete Successfully";
        }else{
            $_SESSION['error'] = "Error"; 
        }
    }catch(Exception $e){
        echo $e->getMessage();
    }

?>