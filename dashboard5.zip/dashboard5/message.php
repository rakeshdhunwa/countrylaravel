<?php
    if(isset($_SESSION['success'])){
?>

   <div class="success"> <?=($_SESSION['success'])?></div>
<?php
    unset($_SESSION['success']);
    }
?>
<?php
    if(isset($_SESSION['error'])){
?>
   <div class="error"> <?=($_SESSION['error'])?></div>
<?php
    unset($_SESSION['error']);
    }
?>
<?php
if(isset($_SESSION['email'])){
?>
<div class="success"> <?=($_SESSION['email'])?></div>
<?php
unset($_SESSION['email']);
}
?>
<?php
    if(isset($_SESSION['oneemail'])){
?>
   <div class="error"> <?=($_SESSION['oneemail'])?></div>
<?php
    unset($_SESSION['oneemail']);
    }
?>
<?php
    if(isset($_SESSION['notmatch'])){
?>
   <div class="error"> <?=($_SESSION['notmatch'])?></div>
<?php
    unset($_SESSION['notmatch']);
    }
?>
<?php
    if(isset($_SESSION['logout'])){
?>
   <div class="error"> <?=($_SESSION['logout'])?></div>
<?php
    unset($_SESSION['logout']);
    }
?>
<?php
    if(isset($_SESSION['countryedit'])){
?>
   <div class="success"> <?=($_SESSION['countryedit'])?></div>
<?php
    unset($_SESSION['countryedit']);
    }
?>
<?php
    if(isset($_SESSION['adddata'])){
?>
   <div class="success"> <?=($_SESSION['adddata'])?></div>
<?php
    unset($_SESSION['adddata']);
    }
?>
<?php
    if(isset($_SESSION['statesdelete'])){
?>
   <div class="success"> <?=($_SESSION['statesdelete'])?></div>
<?php
    unset($_SESSION['statesdelete']);
    }
?>