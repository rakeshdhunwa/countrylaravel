<?php
    include_once("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once('head.php');?>
</head>
<body>
    <div class="contener">
        <div class="navbar">
            <?php include_once('nav.php');?>
        </div>
        <div class="topheader">
            <?php include_once('header.php');?>
        </div> 
        <div class="banner">
            <section>
                <div class="banner2"><br>
                    <div class="searchbutton">
                        <label for="">Search</label>
                        <input type="search" name="search" value="" placeholder="Search">
                    </div>
                    <div class="form">
                        <h2>Country Form</h2><br>
                        <form action="country-create.php" method="post" style="background-color: transparent;">
                            <table border class="ctable">
                                <tr>
                                    <td><label for="">Country Name</label></td>
                                    <td><input type="text" value="" name="name" required placeholder="Name"></td>
                                </tr>
                                <tr>
                                    <td><label for="">Status</label></td>
                                    <td><select name="status" id="status">
                                        <option value="1">Enable</option>   
                                        <option value="2">Disable</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <table class="ctable" id="table2">
                                            <tr>
                                                <th>State Name</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                            <hr>
                                            <tr class="border">
                                                <td><input type="text" placeholder="Name" name="state_name[]"></td>
                                                <td><select name="state_status[]" id="status">
                                                    <option value="1">Enable</option>
                                                    <option value="2">Disable</option>
                                                    </select>
                                                </td>
                                                <td><button id="add" type="button">Add</button></td>
                                            </tr>
                                        </table>
                                    </td>
                                    <hr>
                                </tr>    
                                <tr>
                                    <td><input type="submit" name="submit" value="Save"></td>

                                    <td><input type="submit" name="save_new" value="Save & New"></td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>       
<script>
   $(document).ready(function(){
        var varebl ='<tr><th><input type="text" name="state_name[]" value=""required  placeholder="Name"/></th><td><select name="state_status[]" id="status"><option value="1">Enable</option><option value="2">Disable</option></select> </td><td><button id="Remove">Remove</button></td></tr>';
        $('#add').click(function(){
            $('#table2').append(varebl);
        });

        $('table').on('click','#Remove',function(){
            $(this).closest('tr').remove();
        });
   });
</script>
</body>
</html>